---
Task ID: 1
Agent: Main agent (Z.ai)
Task: Membuat website penjualan semangka sederhana (Next.js 16 fullstack)

Work Log:
- Inisialisasi lingkungan fullstack via init script
- Update prisma/schema.prisma: model Product, Order, OrderItem (SQLite)
- bun run db:push untuk sinkronisasi skema
- Seed 8 produk via scripts/seed.ts (semangka merah/kuning/mini, jus, potongan box, paket hemat)
- API GET /api/products dengan pencarian query ?q=
- API POST /api/orders dengan validasi input (nama, WA, alamat, stok), perhitungan total server-side, transaksi Prisma (create order + decrement stok)
- Zustand store src/lib/cart-store.ts untuk keranjang
- Komponen: Navbar, Hero, Features, ProductGrid (dengan pencarian), HowToOrder, Footer, CartSheet (sheet keranjang + dialog checkout + dialog sukses)
- Halaman utama src/app/page.tsx merangkai semua section
- Metadata & lang="id" di layout.tsx, favicon semangka emoji
- Lint bersih; verifikasi Agent Browser: render OK (desktop+mobile), tambah keranjang, ubah qty, checkout form, order tersimpan di DB (ID 890EN1SB, total Rp148.000), stok berkurang otomatis, pencarian berfungsi, tanpa error console

Stage Summary:
- Website toko semangka lengkap dan berfungsi end-to-end
- File kunci: prisma/schema.prisma, src/app/api/{products,orders}/route.ts, src/app/page.tsx, src/components/store/*, src/lib/cart-store.ts, scripts/seed.ts
- Tema warna: rose/merah semangka + green/hijau kulit, tanpa indigo/biru
