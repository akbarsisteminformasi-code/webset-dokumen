import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

async function main() {
  const count = await db.product.count()
  if (count > 0) {
    console.log('Produk sudah di-seed, skip.')
    return
  }

  await db.product.createMany({
    data: [
      {
        name: 'Semangka Merah Tanpa Biji',
        description: 'Semangka unggulan daging merah pekat, manis khas, praktis tanpa biji. Dipetik paling matang dari kebun.',
        price: 18000,
        unit: 'kg',
        emoji: '🍉',
        badge: 'Terlaris',
        stock: 120,
        featured: true,
      },
      {
        name: 'Semangka Merah Biji',
        description: 'Semangka klasik dengan biji hitam, rasa manis authentic dan banyak air. Favorit keluarga sejak dulu.',
        price: 15000,
        unit: 'kg',
        emoji: '🍉',
        badge: null,
        stock: 150,
        featured: true,
      },
      {
        name: 'Semangka Kuning Premium',
        description: 'Varietas langka dengan daging kuning keemasan, rasa manis lembut dengan aroma honey yang khas.',
        price: 25000,
        unit: 'kg',
        emoji: '🍈',
        badge: 'Premium',
        stock: 40,
        featured: true,
      },
      {
        name: 'Semangka Mini (Icebox)',
        description: 'Ukuran kecil 1.5-2.5 kg, cocok untuk 1-2 orang. Kulit tipis, daging padat dan sangat manis.',
        price: 22000,
        unit: 'buah',
        emoji: '🍉',
        badge: null,
        stock: 60,
        featured: false,
      },
      {
        name: 'Semangka Baby Seedless',
        description: 'Semangka kecil tanpa biji, kulit gelap bergaris. Manis merata sampai ke kulit, portabel dan praktis.',
        price: 28000,
        unit: 'buah',
        emoji: '🍉',
        badge: 'Baru',
        stock: 45,
        featured: false,
      },
      {
        name: 'Potongan Semangka Box',
        description: 'Semangka merah dipotong dadu, siap makan. Dikemas box food grade, higienis, cocok untuk kantor & acara.',
        price: 12000,
        unit: 'box',
        emoji: '📦',
        badge: null,
        stock: 80,
        featured: true,
      },
      {
        name: 'Jus Semangka Segar 500ml',
        description: 'Jus semangka murni tanpa gula tambahan, diperas dari buah segar pilihan. Menyegarkan dan sehat.',
        price: 10000,
        unit: 'cup',
        emoji: '🥤',
        badge: null,
        stock: 100,
        featured: false,
      },
      {
        name: 'Paket Hemat 5 Kg',
        description: 'Hemat untuk acara keluarga: 5 kg semangka merah pilihan + gratis alat potong semangka stainless.',
        price: 79000,
        unit: 'paket',
        emoji: '🎁',
        badge: 'Hemat 15%',
        stock: 30,
        featured: true,
      },
    ],
  })

  console.log('Seed selesai:', await db.product.count(), 'produk')
}

main()
  .catch(console.error)
  .finally(() => db.$disconnect())
