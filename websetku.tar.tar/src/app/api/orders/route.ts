import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

type IncomingItem = {
  productId: string
  quantity: number
}

const PAYMENT_METHODS = ['cod', 'transfer', 'qris']

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { customerName, phone, address, note, paymentMethod, items } = body as {
      customerName?: string
      phone?: string
      address?: string
      note?: string
      paymentMethod?: string
      items?: IncomingItem[]
    }

    // Validasi input
    if (!customerName || customerName.trim().length < 3) {
      return NextResponse.json(
        { error: 'Nama pemesan wajib diisi (minimal 3 karakter).' },
        { status: 400 }
      )
    }
    if (!phone || !/^[0-9+\-\s]{9,16}$/.test(phone.trim())) {
      return NextResponse.json(
        { error: 'Nomor WhatsApp tidak valid.' },
        { status: 400 }
      )
    }
    if (!address || address.trim().length < 10) {
      return NextResponse.json(
        { error: 'Alamat lengkap wajib diisi (minimal 10 karakter).' },
        { status: 400 }
      )
    }
    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: 'Keranjang masih kosong. Tambahkan produk terlebih dahulu.' },
        { status: 400 }
      )
    }
    const method = PAYMENT_METHODS.includes(paymentMethod ?? '')
      ? (paymentMethod as string)
      : 'cod'

    // Ambil produk dari DB dan validasi stok
    const productIds = items.map((i) => i.productId)
    const products = await db.product.findMany({
      where: { id: { in: productIds } },
    })

    if (products.length === 0) {
      return NextResponse.json(
        { error: 'Produk tidak ditemukan.' },
        { status: 400 }
      )
    }

    // Susun item order + hitung total dari harga di DB (bukan dari client)
    const orderItemsData: {
      productId: string
      productName: string
      unitPrice: number
      quantity: number
    }[] = []

    for (const item of items) {
      const product = products.find((p) => p.id === item.productId)
      if (!product) {
        return NextResponse.json(
          { error: 'Ada produk yang sudah tidak tersedia. Muat ulang halaman.' },
          { status: 400 }
        )
      }
      const qty = Math.max(1, Math.floor(Number(item.quantity) || 0))
      if (qty > product.stock) {
        return NextResponse.json(
          { error: `Stok "${product.name}" tersisa ${product.stock} ${product.unit}.` },
          { status: 400 }
        )
      }
      orderItemsData.push({
        productId: product.id,
        productName: product.name,
        unitPrice: product.price,
        quantity: qty,
      })
    }

    const totalPrice = orderItemsData.reduce(
      (sum, i) => sum + i.unitPrice * i.quantity,
      0
    )

    // Simpan order + items + kurangi stok dalam satu transaksi
    const order = await db.$transaction(async (tx) => {
      const created = await tx.order.create({
        data: {
          customerName: customerName.trim(),
          phone: phone.trim(),
          address: address.trim(),
          note: note?.trim() || null,
          paymentMethod: method,
          totalPrice,
          items: {
            create: orderItemsData,
          },
        },
        include: { items: true },
      })

      for (const item of orderItemsData) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stock: { decrement: item.quantity } },
        })
      }

      return created
    })

    return NextResponse.json(
      {
        message: 'Pesanan berhasil dibuat! Kami akan menghubungi Anda via WhatsApp.',
        order: {
          id: order.id,
          totalPrice: order.totalPrice,
          itemCount: order.items.length,
        },
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Gagal membuat pesanan:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan server. Silakan coba lagi.' },
      { status: 500 }
    )
  }
}
