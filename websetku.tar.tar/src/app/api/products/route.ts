import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get('q')?.trim().toLowerCase() ?? ''

    const products = await db.product.findMany({
      orderBy: [{ featured: 'desc' }, { createdAt: 'asc' }],
    })

    const filtered = query
      ? products.filter(
          (p) =>
            p.name.toLowerCase().includes(query) ||
            p.description.toLowerCase().includes(query)
        )
      : products

    return NextResponse.json({ products: filtered })
  } catch (error) {
    console.error('Gagal mengambil produk:', error)
    return NextResponse.json(
      { error: 'Gagal memuat produk. Silakan coba lagi.' },
      { status: 500 }
    )
  }
}
