import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Semangka Segar - Toko Semangka Online Manis & Murah",
  description:
    "Belanja semangka segar langsung dari kebun: merah tanpa biji, kuning premium, mini, jus segar, dan paket hemat. Gratis ongkir, garansi manis, diantar di hari yang sama.",
  keywords: [
    "semangka",
    "jual semangka",
    "semangka online",
    "buah segar",
    "semangka tanpa biji",
    "toko buah",
  ],
  authors: [{ name: "Semangka Segar" }],
  icons: {
    icon: "data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🍉</text></svg>",
  },
  openGraph: {
    title: "Semangka Segar - Toko Semangka Online",
    description:
      "Semangka manis segar langsung dari kebun, diantar di hari yang sama.",
    siteName: "Semangka Segar",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
