'use client'

import { useEffect, useState } from 'react'
import { Navbar } from '@/components/store/navbar'
import { Hero } from '@/components/store/hero'
import { Features } from '@/components/store/features'
import { ProductGrid, type Product } from '@/components/store/product-grid'
import { HowToOrder } from '@/components/store/how-to-order'
import { Footer } from '@/components/store/footer'
import { CartSheet } from '@/components/store/cart-sheet'

export default function Home() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true

    fetch('/api/products')
      .then((res) => res.json())
      .then((data) => {
        if (active && Array.isArray(data.products)) {
          setProducts(data.products)
        }
      })
      .catch(() => {
        // Biarkan tampil state katalog kosong jika gagal
      })
      .finally(() => {
        if (active) setLoading(false)
      })

    return () => {
      active = false
    }
  }, [])

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Features />
        <ProductGrid products={products} loading={loading} />
        <HowToOrder />
      </main>
      <Footer />
      <CartSheet />
    </div>
  )
}
