'use client'

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

const stats = [
  { value: '10.000+', label: 'Pelanggan puas' },
  { value: '4.9/5', label: 'Rating toko' },
  { value: '≤ 2 jam', label: 'Sampai di rumah' },
]

export function Hero() {
  return (
    <section
      aria-labelledby="judul-hero"
      className="relative overflow-hidden bg-gradient-to-b from-rose-50 via-white to-white"
    >
      {/* lingkaran dekoratif */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-rose-100/70 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-28 -right-20 h-80 w-80 rounded-full bg-green-100/80 blur-3xl"
      />

      <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 md:py-24 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: 'easeOut' }}
        >
          <Badge className="mb-4 rounded-full border-0 bg-green-100 px-3 py-1.5 text-xs font-semibold text-green-800">
            🌱 Dipetik pagi, dikirim siang
          </Badge>
          <h1
            id="judul-hero"
            className="text-4xl font-extrabold leading-tight tracking-tight text-green-900 sm:text-5xl"
          >
            Semangka{' '}
            <span className="relative inline-block text-rose-600">
              Manis Segar
              <svg
                aria-hidden="true"
                viewBox="0 0 200 12"
                className="absolute -bottom-1.5 left-0 w-full text-rose-300"
                preserveAspectRatio="none"
              >
                <path
                  d="M2 9 C 50 2, 150 2, 198 8"
                  stroke="currentColor"
                  strokeWidth="4"
                  fill="none"
                  strokeLinecap="round"
                />
              </svg>
            </span>{' '}
            langsung dari kebun
          </h1>
          <p className="mt-5 max-w-lg text-base leading-relaxed text-green-950/70 sm:text-lg">
            Daging merah pekat, renyah, dan penuh air. Dibeli langsung dari
            petani tanpa perantara, dipilih satu per satu, dan diantar
            di hari yang sama supaya kesegarannya terjaga sampai di meja makan
            Anda.
          </p>

          <div className="mt-7 flex flex-wrap items-center gap-3">
            <Button
              asChild
              size="lg"
              className="h-12 rounded-full bg-rose-600 px-7 text-base font-semibold text-white shadow-lg shadow-rose-200 transition hover:bg-rose-700"
            >
              <a href="#produk">Belanja Sekarang</a>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="h-12 rounded-full border-green-300 px-7 text-base font-semibold text-green-800 transition hover:bg-green-50"
            >
              <a href="#cara-pesan">Cara Pesan</a>
            </Button>
          </div>

          <dl className="mt-10 grid max-w-md grid-cols-3 gap-4">
            {stats.map((s) => (
              <div
                key={s.label}
                className="rounded-2xl border border-green-100 bg-white/70 p-3 text-center shadow-sm"
              >
                <dt className="sr-only">{s.label}</dt>
                <dd className="text-lg font-extrabold text-rose-600">{s.value}</dd>
                <dd className="mt-0.5 text-xs text-green-900/60">{s.label}</dd>
              </div>
            ))}
          </dl>
        </motion.div>

        {/* Ilustrasi semangka besar */}
        <motion.div
          aria-hidden="true"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.15, ease: 'easeOut' }}
          className="relative mx-auto hidden aspect-square w-full max-w-md sm:block"
        >
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-rose-100 to-green-50 shadow-inner" />
          <div className="absolute inset-6 grid place-items-center rounded-full bg-white/60 shadow-lg">
            <span className="text-[9rem] leading-none drop-shadow-xl sm:text-[11rem]">
              🍉
            </span>
          </div>
          <motion.span
            className="absolute left-4 top-10 rounded-full bg-white px-3 py-1.5 text-sm font-semibold text-green-800 shadow-md"
            animate={{ y: [0, -8, 0] }}
            transition={{ repeat: Infinity, duration: 3.2, ease: 'easeInOut' }}
          >
            🚚 Gratis antar
          </motion.span>
          <motion.span
            className="absolute bottom-12 right-2 rounded-full bg-white px-3 py-1.5 text-sm font-semibold text-rose-600 shadow-md"
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 3.8, ease: 'easeInOut' }}
          >
            💯 Garansi manis
          </motion.span>
        </motion.div>
      </div>
    </section>
  )
}
