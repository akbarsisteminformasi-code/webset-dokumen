'use client'

import { ShoppingBasket } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCart } from '@/lib/cart-store'

export function Navbar() {
  const items = useCart((s) => s.items)
  const open = useCart((s) => s.open)
  const totalQty = items.reduce((sum, i) => sum + i.quantity, 0)

  return (
    <header className="sticky top-0 z-40 border-b border-green-100 bg-white/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
        <a href="#" className="flex items-center gap-2.5" aria-label="Semangka Segar - beranda">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-rose-500 to-rose-600 text-xl shadow-md shadow-rose-200">
            🍉
          </span>
          <span className="leading-tight">
            <span className="block text-base font-extrabold tracking-tight text-green-800">
              Semangka Segar
            </span>
            <span className="block text-[11px] font-medium text-rose-600">
              Panen Hari Ini, Kirim Cepat
            </span>
          </span>
        </a>

        <nav aria-label="Navigasi utama" className="hidden items-center gap-6 text-sm font-medium text-green-900/80 md:flex">
          <a href="#produk" className="transition-colors hover:text-rose-600">Produk</a>
          <a href="#keunggulan" className="transition-colors hover:text-rose-600">Keunggulan</a>
          <a href="#cara-pesan" className="transition-colors hover:text-rose-600">Cara Pesan</a>
        </nav>

        <Button
          onClick={open}
          className="relative gap-2 rounded-full bg-green-700 px-4 text-white shadow-md shadow-green-200 transition hover:bg-green-800"
          aria-label={`Buka keranjang belanja, ${totalQty} item`}
        >
          <ShoppingBasket className="h-5 w-5" aria-hidden="true" />
          <span className="hidden sm:inline">Keranjang</span>
          {totalQty > 0 && (
            <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[11px] font-bold text-white">
              {totalQty}
            </span>
          )}
        </Button>
      </div>
    </header>
  )
}
