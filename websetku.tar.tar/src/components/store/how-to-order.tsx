'use client'

import { motion } from 'framer-motion'
import { MousePointerClick, ClipboardList, PackageCheck } from 'lucide-react'

const steps = [
  {
    icon: MousePointerClick,
    step: '1',
    title: 'Pilih Produk',
    desc: 'Jelajahi katalog dan tambahkan semangka pilihan Anda ke keranjang. Atur jumlahnya sesuai kebutuhan keluarga atau acara Anda.',
  },
  {
    icon: ClipboardList,
    step: '2',
    title: 'Isi Data Pengiriman',
    desc: 'Lengkapi nama, nomor WhatsApp, dan alamat. Pilih metode pembayaran yang paling nyaman: COD, transfer bank, atau QRIS.',
  },
  {
    icon: PackageCheck,
    step: '3',
    title: 'Terima Pesanan',
    desc: 'Tim kami konfirmasi via WhatsApp, lalu semangka dipetik, dikemas rapi, dan diantar di hari yang sama. Bayar saat buah sudah di tangan untuk COD.',
  },
]

export function HowToOrder() {
  return (
    <section
      id="cara-pesan"
      aria-labelledby="judul-cara-pesan"
      className="relative overflow-hidden bg-green-800 py-16 text-white md:py-20"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-green-700/60 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-rose-600/20 blur-3xl"
      />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-rose-300">
            Semudah 1-2-3
          </p>
          <h2
            id="judul-cara-pesan"
            className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl"
          >
            Cara Memesan
          </h2>
          <p className="mt-3 text-base leading-relaxed text-green-50/80">
            Tidak perlu daftar akun, tidak perlu aplikasi tambahan. Tiga
            langkah singkat dan semangka segar meluncur ke alamat Anda.
          </p>
        </div>

        <ol className="mt-12 grid gap-5 md:grid-cols-3">
          {steps.map((s, idx) => (
            <motion.li
              key={s.step}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.45, delay: idx * 0.12 }}
              className="relative rounded-3xl border border-green-700/60 bg-green-900/40 p-6 backdrop-blur-sm"
            >
              <span
                className="absolute -top-4 left-6 grid h-9 w-9 place-items-center rounded-full bg-rose-500 text-sm font-extrabold text-white shadow-lg shadow-rose-900/40"
                aria-hidden="true"
              >
                {s.step}
              </span>
              <s.icon className="mt-2 h-9 w-9 text-rose-300" aria-hidden="true" />
              <h3 className="mt-3 text-lg font-bold">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-green-50/75">
                {s.desc}
              </p>
            </motion.li>
          ))}
        </ol>
      </div>
    </section>
  )
}
