'use client'

import { useState } from 'react'
import {
  Minus,
  Plus,
  ShoppingBasket,
  Trash2,
  Truck,
  PartyPopper,
  Banknote,
  Landmark,
  QrCode,
} from 'lucide-react'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import { useCart, formatRupiah } from '@/lib/cart-store'

type CheckoutInfo = {
  customerName: string
  phone: string
  address: string
  note: string
  paymentMethod: string
}

const EMPTY_FORM: CheckoutInfo = {
  customerName: '',
  phone: '',
  address: '',
  note: '',
  paymentMethod: 'cod',
}

const PAYMENTS = [
  { value: 'cod', label: 'Bayar di Tempat (COD)', icon: Banknote },
  { value: 'transfer', label: 'Transfer Bank', icon: Landmark },
  { value: 'qris', label: 'QRIS', icon: QrCode },
]

export function CartSheet() {
  const { items, isOpen, close, setQuantity, removeItem, clear } = useCart()
  const { toast } = useToast()

  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [form, setForm] = useState<CheckoutInfo>(EMPTY_FORM)
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState<{ id: string; total: number } | null>(null)

  const totalPrice = items.reduce((sum, i) => sum + i.price * i.quantity, 0)
  const totalQty = items.reduce((sum, i) => sum + i.quantity, 0)
  const freeShipping = totalPrice >= 100000

  const updateForm = (key: keyof CheckoutInfo, value: string) =>
    setForm((f) => ({ ...f, [key]: value }))

  const openCheckout = () => {
    close()
    setCheckoutOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (items.length === 0) {
      toast({
        title: 'Keranjang kosong',
        description: 'Tambahkan produk terlebih dahulu sebelum checkout.',
        variant: 'destructive',
      })
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          items: items.map((i) => ({ productId: i.id, quantity: i.quantity })),
        }),
      })
      const data = await res.json()

      if (!res.ok) {
        toast({
          title: 'Pesanan gagal',
          description: data.error ?? 'Terjadi kesalahan. Silakan coba lagi.',
          variant: 'destructive',
        })
        return
      }

      setSuccess({ id: data.order.id, total: data.order.totalPrice })
      clear()
      setForm(EMPTY_FORM)
      setCheckoutOpen(false)
    } catch {
      toast({
        title: 'Koneksi bermasalah',
        description: 'Periksa koneksi internet Anda lalu coba lagi.',
        variant: 'destructive',
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <>
      <Sheet open={isOpen} onOpenChange={(o) => (o ? undefined : close())}>
        <SheetContent
          side="right"
          className="flex w-full flex-col gap-0 border-green-100 p-0 sm:max-w-md"
        >
          <SheetHeader className="space-y-1 border-b border-green-100 px-5 py-4">
            <SheetTitle className="flex items-center gap-2 text-lg font-extrabold text-green-900">
              <ShoppingBasket className="h-5 w-5 text-rose-600" aria-hidden="true" />
              Keranjang Anda
            </SheetTitle>
            <SheetDescription className="text-sm text-green-950/60">
              {totalQty > 0
                ? `${totalQty} item siap dikirim ke rumah Anda`
                : 'Belum ada produk di keranjang'}
            </SheetDescription>
          </SheetHeader>

          {items.length === 0 ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
              <span className="text-6xl" aria-hidden="true">🛒</span>
              <p className="text-lg font-bold text-green-900">
                Keranjang masih kosong
              </p>
              <p className="max-w-xs text-sm leading-relaxed text-green-950/60">
                Jelajahi katalog kami dan tambahkan semangka segar pilihan
                untuk keluarga Anda.
              </p>
              <Button
                asChild
                className="mt-2 rounded-full bg-rose-600 text-white hover:bg-rose-700"
              >
                <a href="#produk" onClick={close}>Lihat Produk</a>
              </Button>
            </div>
          ) : (
            <>
              <ScrollArea className="flex-1 px-5">
                <ul className="divide-y divide-green-100 py-2" aria-label="Daftar item keranjang">
                  {items.map((item) => (
                    <li key={item.id} className="flex gap-3 py-4">
                      <span
                        className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-rose-50 text-3xl"
                        role="img"
                        aria-label={item.name}
                      >
                        {item.emoji}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold text-green-900">
                          {item.name}
                        </p>
                        <p className="mt-0.5 text-xs text-green-950/55">
                          {formatRupiah(item.price)} / {item.unit}
                        </p>
                        <div className="mt-2 flex items-center gap-2">
                          <div className="flex items-center rounded-full border border-green-200">
                            <button
                              type="button"
                              onClick={() => setQuantity(item.id, item.quantity - 1)}
                              className="grid h-7 w-7 place-items-center rounded-l-full text-green-800 transition hover:bg-green-50 disabled:opacity-40"
                              disabled={item.quantity <= 1}
                              aria-label={`Kurangi jumlah ${item.name}`}
                            >
                              <Minus className="h-3.5 w-3.5" aria-hidden="true" />
                            </button>
                            <span className="w-8 text-center text-sm font-bold text-green-900" aria-live="polite">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => setQuantity(item.id, item.quantity + 1)}
                              className="grid h-7 w-7 place-items-center rounded-r-full text-green-800 transition hover:bg-green-50 disabled:opacity-40"
                              disabled={item.quantity >= item.stock}
                              aria-label={`Tambah jumlah ${item.name}`}
                            >
                              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                            </button>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeItem(item.id)}
                            className="grid h-7 w-7 place-items-center rounded-full text-red-400 transition hover:bg-red-50 hover:text-red-600"
                            aria-label={`Hapus ${item.name} dari keranjang`}
                          >
                            <Trash2 className="h-4 w-4" aria-hidden="true" />
                          </button>
                        </div>
                      </div>
                      <p className="shrink-0 text-sm font-extrabold text-rose-600">
                        {formatRupiah(item.price * item.quantity)}
                      </p>
                    </li>
                  ))}
                </ul>
              </ScrollArea>

              <SheetFooter className="space-y-3 border-t border-green-100 px-5 py-4">
                <div
                  className={`flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold ${
                    freeShipping
                      ? 'bg-green-50 text-green-800'
                      : 'bg-amber-50 text-amber-800'
                  }`}
                >
                  <Truck className="h-4 w-4 shrink-0" aria-hidden="true" />
                  {freeShipping
                    ? 'Selamat! Anda dapat gratis ongkir 🎉'
                    : `Tambah ${formatRupiah(100000 - totalPrice)} lagi untuk gratis ongkir`}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-green-950/60">Total belanja</span>
                  <span className="text-xl font-extrabold text-green-900" aria-live="polite">
                    {formatRupiah(totalPrice)}
                  </span>
                </div>
                <Button
                  onClick={openCheckout}
                  size="lg"
                  className="h-12 w-full rounded-full bg-rose-600 text-base font-bold text-white shadow-lg shadow-rose-200 hover:bg-rose-700"
                >
                  Lanjut ke Pengiriman
                </Button>
              </SheetFooter>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* Dialog Checkout */}
      <Dialog open={checkoutOpen} onOpenChange={(o) => (o ? undefined : setCheckoutOpen(false))}>
        <DialogContent className="max-h-[90vh] overflow-y-auto border-green-100 sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-extrabold text-green-900">
              Data Pengiriman
            </DialogTitle>
            <DialogDescription className="text-sm leading-relaxed text-green-950/60">
              {items.length} jenis produk · {totalQty} item ·{' '}
              <span className="font-bold text-rose-600">{formatRupiah(totalPrice)}</span>
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="nama">Nama Lengkap *</Label>
              <Input
                id="nama"
                value={form.customerName}
                onChange={(e) => updateForm('customerName', e.target.value)}
                placeholder="cth: Budi Santoso"
                required
                minLength={3}
                className="border-green-200 focus-visible:ring-rose-400"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="wa">Nomor WhatsApp *</Label>
              <Input
                id="wa"
                type="tel"
                value={form.phone}
                onChange={(e) => updateForm('phone', e.target.value)}
                placeholder="cth: 0812xxxxxxx"
                required
                className="border-green-200 focus-visible:ring-rose-400"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="alamat">Alamat Lengkap *</Label>
              <Textarea
                id="alamat"
                value={form.address}
                onChange={(e) => updateForm('address', e.target.value)}
                placeholder="Jalan, nomor rumah, RT/RW, kelurahan, kecamatan, kota"
                required
                minLength={10}
                rows={3}
                className="resize-none border-green-200 focus-visible:ring-rose-400"
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="pembayaran">Metode Pembayaran</Label>
                <Select
                  value={form.paymentMethod}
                  onValueChange={(v) => updateForm('paymentMethod', v)}
                >
                  <SelectTrigger id="pembayaran" className="border-green-200 focus:ring-rose-400">
                    <SelectValue placeholder="Pilih metode" />
                  </SelectTrigger>
                  <SelectContent>
                    {PAYMENTS.map((p) => (
                      <SelectItem key={p.value} value={p.value}>
                        {p.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="catatan">Catatan (opsional)</Label>
                <Input
                  id="catatan"
                  value={form.note}
                  onChange={(e) => updateForm('note', e.target.value)}
                  placeholder="cth: pilih yang paling manis"
                  className="border-green-200 focus-visible:ring-rose-400"
                />
              </div>
            </div>

            <Separator className="bg-green-100" />

            <div className="rounded-2xl bg-rose-50/60 p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-green-950/65">Ongkir</span>
                <span className={freeShipping ? 'font-bold text-green-700' : 'font-semibold text-green-900'}>
                  {freeShipping ? 'GRATIS' : formatRupiah(9000)}
                </span>
              </div>
              <div className="mt-1.5 flex items-center justify-between">
                <span className="text-sm font-semibold text-green-950/70">
                  Total bayar
                </span>
                <span className="text-lg font-extrabold text-rose-600">
                  {formatRupiah(totalPrice + (freeShipping ? 0 : 9000))}
                </span>
              </div>
            </div>

            <DialogFooter className="gap-2 sm:gap-0">
              <Button
                type="button"
                variant="outline"
                onClick={() => setCheckoutOpen(false)}
                className="rounded-full border-green-200 text-green-800 hover:bg-green-50"
                disabled={submitting}
              >
                Kembali
              </Button>
              <Button
                type="submit"
                disabled={submitting}
                className="rounded-full bg-rose-600 font-bold text-white shadow-md shadow-rose-200 hover:bg-rose-700"
              >
                {submitting ? 'Memproses...' : 'Buat Pesanan'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog Sukses */}
      <Dialog open={!!success} onOpenChange={(o) => (o ? undefined : setSuccess(null))}>
        <DialogContent className="border-green-100 text-center sm:max-w-md">
          <DialogHeader className="items-center">
            <span className="mx-auto text-6xl" aria-hidden="true">🎉</span>
            <DialogTitle className="flex items-center justify-center gap-2 pt-2 text-2xl font-extrabold text-green-900">
              <PartyPopper className="h-6 w-6 text-rose-500" aria-hidden="true" />
              Pesanan Berhasil!
            </DialogTitle>
            <DialogDescription className="pt-2 text-sm leading-relaxed text-green-950/65">
              Terima kasih! Pesanan Anda sudah kami terima dan akan segera
              diproses. Tim kami akan menghubungi Anda via WhatsApp untuk
              konfirmasi pengiriman.
            </DialogDescription>
          </DialogHeader>
          {success && (
            <div className="mx-auto w-full max-w-xs space-y-1.5 rounded-2xl bg-green-50 p-4 text-sm">
              <p className="flex justify-between">
                <span className="text-green-950/60">No. Pesanan</span>
                <span className="font-mono font-bold text-green-900">
                  {success.id.slice(-8).toUpperCase()}
                </span>
              </p>
              <p className="flex justify-between">
                <span className="text-green-950/60">Total</span>
                <span className="font-extrabold text-rose-600">
                  {formatRupiah(success.total)}
                </span>
              </p>
            </div>
          )}
          <Button
            onClick={() => setSuccess(null)}
            className="w-full rounded-full bg-green-700 font-bold text-white hover:bg-green-800"
          >
            Selesai
          </Button>
        </DialogContent>
      </Dialog>
    </>
  )
}
