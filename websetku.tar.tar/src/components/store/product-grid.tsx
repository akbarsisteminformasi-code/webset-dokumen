'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Loader2, Minus, Plus, Search, ShoppingBasket } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { useCart, formatRupiah, type CartProduct } from '@/lib/cart-store'

export type Product = CartProduct & {
  description: string
  badge: string | null
  featured: boolean
}

function ProductCard({ product, index }: { product: Product; index: number }) {
  const addItem = useCart((s) => s.addItem)
  const [added, setAdded] = useState(false)

  const handleAdd = () => {
    addItem(product)
    setAdded(true)
    setTimeout(() => setAdded(false), 1200)
  }

  return (
    <motion.article
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.45, delay: (index % 4) * 0.07 }}
      className="group flex flex-col overflow-hidden rounded-3xl border border-green-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl hover:shadow-rose-100/70"
    >
      <div className="relative grid aspect-[4/3] place-items-center bg-gradient-to-br from-rose-50 via-white to-green-50">
        <span
          className="text-7xl transition duration-300 group-hover:scale-110 sm:text-8xl"
          role="img"
          aria-label={product.name}
        >
          {product.emoji}
        </span>
        {product.badge && (
          <Badge className="absolute left-3 top-3 rounded-full border-0 bg-rose-600 px-2.5 py-1 text-[11px] font-bold text-white shadow">
            {product.badge}
          </Badge>
        )}
        {product.stock <= 45 && (
          <Badge className="absolute right-3 top-3 rounded-full border-0 bg-amber-500 px-2.5 py-1 text-[11px] font-bold text-white shadow">
            Stok terbatas
          </Badge>
        )}
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-base font-bold leading-snug text-green-900">
          {product.name}
        </h3>
        <p className="mt-1.5 line-clamp-2 flex-1 text-sm leading-relaxed text-green-950/60">
          {product.description}
        </p>

        <div className="mt-4 flex items-end justify-between gap-2">
          <div>
            <p className="text-lg font-extrabold text-rose-600">
              {formatRupiah(product.price)}
            </p>
            <p className="text-xs text-green-900/55">
              per {product.unit} · stok {product.stock}
            </p>
          </div>
          <Button
            onClick={handleAdd}
            size="sm"
            className={`h-10 gap-1.5 rounded-full px-4 font-semibold text-white shadow-md transition ${
              added
                ? 'bg-green-600 hover:bg-green-700'
                : 'bg-rose-600 hover:bg-rose-700'
            }`}
            aria-label={`Tambah ${product.name} ke keranjang`}
          >
            {added ? (
              <>
                <Plus className="h-4 w-4" aria-hidden="true" /> Ditambah
              </>
            ) : (
              <>
                <ShoppingBasket className="h-4 w-4" aria-hidden="true" /> Tambah
              </>
            )}
          </Button>
        </div>
      </div>
    </motion.article>
  )
}

export function ProductGrid({
  products,
  loading,
}: {
  products: Product[]
  loading: boolean
}) {
  const [query, setQuery] = useState('')
  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(query.toLowerCase()) ||
      p.description.toLowerCase().includes(query.toLowerCase())
  )

  return (
    <section id="produk" aria-labelledby="judul-produk" className="bg-gradient-to-b from-white via-rose-50/40 to-white py-16 md:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-rose-600">
            Katalog buah
          </p>
          <h2
            id="judul-produk"
            className="mt-2 text-3xl font-extrabold tracking-tight text-green-900 sm:text-4xl"
          >
            Pilih Semangka Favoritmu
          </h2>
          <p className="mt-3 text-base leading-relaxed text-green-950/70">
            Dari semangka utuh tanpa biji sampai jus segar siap minum. Semua
            harga di bawah adalah harga langsung dari kebun.
          </p>
        </div>

        <div className="mx-auto mt-8 max-w-md">
          <label htmlFor="cari-produk" className="sr-only">
            Cari produk
          </label>
          <div className="relative">
            <Search
              className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-green-900/40"
              aria-hidden="true"
            />
            <Input
              id="cari-produk"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Cari semangka, jus, paket hemat..."
              className="h-12 rounded-full border-green-200 bg-white pl-11 text-base shadow-sm focus-visible:ring-rose-400"
            />
          </div>
        </div>

        {loading ? (
          <div className="mt-12 flex flex-col items-center justify-center gap-3 py-16 text-green-900/60">
            <Loader2 className="h-8 w-8 animate-spin text-rose-500" aria-hidden="true" />
            <p className="text-sm font-medium">Memuat produk segar...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="mt-12 rounded-3xl border border-dashed border-green-200 bg-white p-12 text-center">
            <span className="text-5xl" aria-hidden="true">🔍</span>
            <p className="mt-4 text-lg font-bold text-green-900">
              Produk tidak ditemukan
            </p>
            <p className="mt-1 text-sm text-green-950/60">
              Coba kata kunci lain, misalnya &quot;semangka kuning&quot; atau &quot;paket&quot;.
            </p>
          </div>
        ) : (
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {filtered.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
