'use client'

import { MapPin, Phone, Clock } from 'lucide-react'

export function Footer() {
  return (
    <footer className="mt-auto border-t border-green-100 bg-green-50/60">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-rose-500 to-rose-600 text-lg shadow">
              🍉
            </span>
            <span className="text-base font-extrabold text-green-900">
              Semangka Segar
            </span>
          </div>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-green-950/65">
            Toko buah keluarga yang menyediakan semangka terbaik langsung dari
            kebun mitra petani. Segar, manis, dan bergaransi sejak 2020.
          </p>
        </div>

        <nav aria-label="Tautan cepat">
          <h3 className="text-sm font-bold uppercase tracking-wider text-green-900">
            Tautan Cepat
          </h3>
          <ul className="mt-3 space-y-2 text-sm text-green-950/70">
            <li>
              <a href="#produk" className="transition hover:text-rose-600">
                Katalog Produk
              </a>
            </li>
            <li>
              <a href="#keunggulan" className="transition hover:text-rose-600">
                Keunggulan Kami
              </a>
            </li>
            <li>
              <a href="#cara-pesan" className="transition hover:text-rose-600">
                Cara Memesan
              </a>
            </li>
          </ul>
        </nav>

        <address className="not-italic">
          <h3 className="text-sm font-bold uppercase tracking-wider text-green-900">
            Hubungi Kami
          </h3>
          <ul className="mt-3 space-y-2.5 text-sm text-green-950/70">
            <li className="flex items-start gap-2">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" aria-hidden="true" />
              Jl. Kebun Melon No. 8, Indramayu, Jawa Barat
            </li>
            <li className="flex items-center gap-2">
              <Phone className="h-4 w-4 shrink-0 text-rose-500" aria-hidden="true" />
              0812-3456-7890 (WhatsApp)
            </li>
            <li className="flex items-center gap-2">
              <Clock className="h-4 w-4 shrink-0 text-rose-500" aria-hidden="true" />
              Setiap hari, 07.00 - 20.00 WIB
            </li>
          </ul>
        </address>
      </div>

      <div className="border-t border-green-100 py-4">
        <p className="text-center text-xs text-green-950/50">
          © {new Date().getFullYear()} Semangka Segar · Buah terbaik untuk keluarga Indonesia
        </p>
      </div>
    </footer>
  )
}
