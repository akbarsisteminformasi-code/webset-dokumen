'use client'

import { motion } from 'framer-motion'
import { Truck, Leaf, ShieldCheck, Wallet } from 'lucide-react'

const features = [
  {
    icon: Leaf,
    title: 'Panen Hari Ini',
    desc: 'Setiap semangka dipetik subuh dari kebun mitra petani di Indramayu & Banyuwangi, lalu langsung disortir dan dikemas pada hari yang sama. Tidak ada stok menginap.',
  },
  {
    icon: Truck,
    title: 'Kirim Cepat & Gratis',
    desc: 'Pesan sebelum jam 15.00, semangka sampai di hari yang sama untuk area kota. Gratis ongkir untuk pembelian di atas Rp100.000 dengan pengemasan anti benturan.',
  },
  {
    icon: ShieldCheck,
    title: 'Garansi Manis',
    desc: 'Semangka disortir manual satu per satu menggunakan uji ketukan dan tingkat kemanisan. Jika tidak manis, kami ganti baru atau kembalikan uang Anda 100%.',
  },
  {
    icon: Wallet,
    title: 'Harga Petani Langsung',
    desc: 'Tanpa perantara pasar, harga jadi jauh lebih terjangkau. Setiap pembelian juga berkontribusi langsung pada kesejahteraan petani mitra kami.',
  },
]

export function Features() {
  return (
    <section id="keunggulan" aria-labelledby="judul-keunggulan" className="bg-white py-16 md:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-rose-600">
            Kenapa belanja di sini
          </p>
          <h2
            id="judul-keunggulan"
            className="mt-2 text-3xl font-extrabold tracking-tight text-green-900 sm:text-4xl"
          >
            Segar dari Kebun, Sampai ke Rumah Anda
          </h2>
          <p className="mt-3 text-base leading-relaxed text-green-950/70">
            Kami percaya buah terbaik adalah buah yang baru saja lepas dari
            tangkainya. Empat komitmen ini yang membuat pelanggan terus kembali
            memesan semangka kepada kami.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, idx) => (
            <motion.article
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.45, delay: idx * 0.08 }}
              className="group rounded-3xl border border-green-100 bg-gradient-to-b from-white to-rose-50/40 p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg hover:shadow-rose-100"
            >
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-green-100 text-green-700 transition group-hover:bg-rose-100 group-hover:text-rose-600">
                <f.icon className="h-6 w-6" aria-hidden="true" />
              </span>
              <h3 className="mt-4 text-lg font-bold text-green-900">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-green-950/65">
                {f.desc}
              </p>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}
