'use client'

import { create } from 'zustand'

export type CartProduct = {
  id: string
  name: string
  price: number
  unit: string
  emoji: string
  stock: number
}

export type CartItem = CartProduct & { quantity: number }

type CartState = {
  items: CartItem[]
  isOpen: boolean
  open: () => void
  close: () => void
  addItem: (product: CartProduct) => void
  removeItem: (id: string) => void
  setQuantity: (id: string, quantity: number) => void
  clear: () => void
}

export const useCart = create<CartState>((set) => ({
  items: [],
  isOpen: false,
  open: () => set({ isOpen: true }),
  close: () => set({ isOpen: false }),

  addItem: (product) =>
    set((state) => {
      const existing = state.items.find((i) => i.id === product.id)
      if (existing) {
        // Sudah di keranjang: naikkan jumlah (maksimal stok)
        return {
          items: state.items.map((i) =>
            i.id === product.id
              ? { ...i, quantity: Math.min(i.quantity + 1, i.stock) }
              : i
          ),
        }
      }
      return {
        items: [...state.items, { ...product, quantity: 1 }],
      }
    }),

  removeItem: (id) =>
    set((state) => ({ items: state.items.filter((i) => i.id !== id) })),

  setQuantity: (id, quantity) =>
    set((state) => ({
      items: state.items.map((i) =>
        i.id === id
          ? { ...i, quantity: Math.max(1, Math.min(quantity, i.stock)) }
          : i
      ),
    })),

  clear: () => set({ items: [] }),
}))

export const formatRupiah = (value: number) =>
  new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
  }).format(value)
